﻿#kraterek
from math import sqrt

def feladat1() :
    fnev="felszin_tpont.txt"
    be = open(fnev)
    sorok = []
    for s in be :
        if s!= "\n" : 
            sorok.append( s.strip() )
    be.close()
    return sorok

def feladat2(kraterek) :
    print("2. feladat")
    print( "A kráterek száma:", len(kraterek) )

def feladat3(kraterek) :
    print("3. feladat")
    knev = input("Kérem egy kráter nevét: ")
    i = 0
    while i<len(kraterek) and knev != kraterek[i][3] :
        i += 1
    if i<len(kraterek) :
        print("A(z) {0} középpontja X={1} Y={2} sugara R={3}.".
            format(knev, kraterek[i][0], kraterek[i][1], kraterek[i][2]) )
    else :
        print("Nincs ilyen nevű kráter.")

def feladat4(kraterek) :
    print("4. feladat")
    maxind = 0
    maxsugar = 0
    for i in range(len(kraterek)) :
        if kraterek[i][2]>maxsugar :
            maxsugar = kraterek[i][2]
            maxind = i
    print("A legnagyobb kráter neve és sugara:", kraterek[maxind][3],maxsugar )
          
def tavolsag(x1,y1,x2,y2) :
    return sqrt( (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1) )

def feladat6(kraterek) :
    print("6. feladat")
    knev = input("Kérem egy kráter nevét: ")
    ki = 0
    while kraterek[ki][3] != knev :
        ki += 1
    print("Nincs közös része: ",end="")
    nincsk = []
    for i in range(len(kraterek)) :
        tav = tavolsag( kraterek[ki][0], kraterek[ki][1], kraterek[i][0], kraterek[i][1] )
        if tav>kraterek[ki][2] + kraterek[i][2] :
            nincsk.append( kraterek[i][3] )
    print(", ".join(nincsk),end=".\n")
    
def feladat7(kraterek) :
    print("7. feladat")
    for i in range(len(kraterek)-1) :
        for j in range(i+1,len(kraterek)) :
            if kraterek[i][2]>kraterek[j][2] :
                nagy = kraterek[i]
                kis = kraterek[j]
            else :
                nagy = kraterek[j]
                kis = kraterek[i]
            tav = tavolsag( nagy[0], nagy[1], kis[0], kis[1] )
            if tav<nagy[2]-kis[2] :
                print( "A(z) {0} kráter tartalmazza a(z) {1} krátert.".format(nagy[3],kis[3]))

def feladat8(kraterek) :
    ki = open("terulet.txt","wt")
    for krat in kraterek:
        ter = krat[2]*krat[2]*3.14
        print(round(ter,2),krat[3],sep='\t',file=ki)
    ki.close()
    
# főprogram
sorok = feladat1()
kraterek = []
for sor in sorok :
    kra = sor.split('\t')
    krater = [ float(kra[0]), float(kra[1]), float(kra[2]), kra[3] ]
    kraterek.append(krater)
feladat2(kraterek)
feladat3(kraterek)
feladat4(kraterek)
feladat6(kraterek)
feladat7(kraterek)
feladat8(kraterek)

