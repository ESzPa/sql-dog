SELECT nev, Sum(meddig-mettol+1)
FROM uralkodo, hivatal
WHERE uralkodo.azon = hivatal.uralkodo_az
GROUP BY nev
HAVING Count(hivatal.azon)>1;
