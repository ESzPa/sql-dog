SELECT nev, mettol-szul 
FROM uralkodo,  hivatal
WHERE uralkodo.azon=hivatal.uralkodo_az AND
mettol-szul<15
ORDER BY 2;