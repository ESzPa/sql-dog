SELECT uralkodo.nev, meddig-mettol+1 AS hossz
FROM uralkodo, hivatal
WHERE uralkodo.azon=hivatal.uralkodo_az
ORDER BY hossz DESC
LIMIT 1;