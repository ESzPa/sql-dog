SELECT uralkodohaz.nev, count(uralkodo.azon)
FROM uralkodohaz, uralkodo
WHERE uralkodohaz.azon=uralkodo.uhaz_az
GROUP BY 1
ORDER BY 2 DESC;