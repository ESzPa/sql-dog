SELECT uralkodo.nev, mettol, meddig
FROM uralkodo, hivatal, uralkodohaz
WHERE uralkodo.azon=hivatal.uralkodo_az AND uralkodo.uhaz_az=uralkodohaz.azon
AND uralkodohaz.nev="Árpád-ház"
ORDER BY mettol;