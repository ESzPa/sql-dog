SELECT nev, ragnev
FROM uralkodo
WHERE ragnev IS NOT NULL
ORDER BY szul;
