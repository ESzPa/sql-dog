SELECT nev
FROM uralkodo, hivatal
WHERE uralkodo.azon = hivatal.uralkodo_az AND
koronazas>mettol;
