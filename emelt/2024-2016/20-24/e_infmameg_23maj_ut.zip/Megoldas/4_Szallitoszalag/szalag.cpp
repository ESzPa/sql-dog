#include <iostream>
#include <fstream>

using namespace std;
struct Trekesz {
	int indul;
	int honnan, hova;
	int celban;
	int tomeg;
};
struct Tpozicio {
	int hely;
	int tomeg;
};
int tav(int szalaghossz, int indulashelye, int erkezeshelye)
{
	if(erkezeshelye>indulashelye)
	{
		return erkezeshelye-indulashelye;
	}
	else
	{
		return szalaghossz-(indulashelye-erkezeshelye);
	}
}
int main()
{
    int hossz, ido;
    Trekesz r[1000];
    ifstream be("szallit.txt");
    be >> hossz >> ido;
    int i=0;
    while(be >> r[i].indul >> r[i].honnan >> r[i].hova >> r[i].tomeg)
	{
		i++;
	}
	int db=i;
	be.close();

	cout << "2. feladat" << endl;
	int hely;
	cout << "Adja meg, melyik adatsorra kivancsi! ";
	cin >> hely;
	cout << "Honnan: " << r[hely-1].honnan << " Hova: " << r[hely-1].hova << endl;

	cout << "4. feladat" << endl;
	int maxtav=0;
	for(int i=0; i<db; i++)
	{
		maxtav=max(tav(hossz, r[i].honnan, r[i].hova), maxtav);
	}
	cout << "A legnagyobb tavolsag: " << maxtav << endl;
	cout << "A maximalis tavolsagu szallitasok: ";
	for(int i=0; i<db; i++)
	{
		if(tav(hossz, r[i].honnan, r[i].hova)==maxtav)
		{
			cout << i+1 << " ";
		}
	}
	cout << endl;

	cout << "5. feladat" << endl;
	int ossztomeg=0;
	for(int i=0; i<db; i++)
	{
		if(r[i].honnan>r[i].hova)
		{
			ossztomeg+=r[i].tomeg;
		}
	}
	cout << "A kezdopont elott elhalado rekeszek ossztomege: " << ossztomeg << endl;

	cout << "6. feladat" << endl;
	int mikor;
	cout << "Adja meg a kivant idopontot! ";
	cin >> mikor;
	int mozgo=0;
	cout << "A szallitott rekeszek halmaza: ";
	for(int i=0; i<db; i++)
	{
		if(r[i].indul<=mikor and r[i].indul+tav(hossz, r[i].honnan, r[i].hova)*ido>mikor)
		{
			mozgo++;
			cout << i+1 << " ";
		}
	}
	if(mozgo==0)
	{
		cout << "ures.";
	}
	cout << endl;


	cout << "7. feladat" << endl;
	int tomeg[500]={0};
	for(int i=0; i<db; i++)
	{
		tomeg[r[i].honnan]+=r[i].tomeg;
	}
	ofstream ki("tomeg.txt");
	for(int i=0; i<hossz; i++)
	{
		if(tomeg[i]>0)
		{
			ki << i << " " << tomeg[i] << endl;
		}
	}
	ki.close();
    return 0;
}
